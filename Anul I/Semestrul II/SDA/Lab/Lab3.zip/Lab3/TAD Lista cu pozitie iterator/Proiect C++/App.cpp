#include <iostream>

#include "TestScurt.h"
#include "TestExtins.h"

int main(){
    testAll();
    testAllExtins();
    std::cout<<"Finished LP Tests!"<<std::endl;
}
